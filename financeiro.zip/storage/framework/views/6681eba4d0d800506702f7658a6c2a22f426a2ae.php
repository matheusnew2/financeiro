<?php $__env->startSection('title'); ?>
Tipo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <form method="POST" action="<?php echo e(asset('Tipo')); ?>" id="form" class="form-row form-group">
        <?php echo csrf_field(); ?>
        <?php if(isset($result)): ?>
            <?php if($result->id_tipo !== NULL): ?>
        <input type="hidden" value="<?php echo e($result->id_tipo); ?>" name="id_tipo">
            <?php endif; ?>
        <?php endif; ?>
        <div class="col-sm-6">
           
            <div class="form-group col-sm-12">
                <label for="valor">Nome</label>
                <input type="text" name="nome" value="<?php if(isset($result->nome)): ?><?php echo e($result->nome); ?><?php endif; ?>" required class="form-control">
            </div>
            <div class="form-group col-sm-12">
                <label for="descricao">Tipo</label>
                <select class="form-control" name="tipo">
                    <option value="L" <?php if(isset($result->tipo)): ?> <?php if($result->tipo == 'L'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Lucro</option>
                    <option value="D" <?php if(isset($result->tipo)): ?> <?php if($result->tipo == 'D'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Despesa</option>
                </select>
            </div>
            

            <div class="col-sm-12">
                <input type="submit" class="btn btn-success">
                <input type="button" onclick="window.location.href='<?php echo e(asset('ListaTipo')); ?>'" value="Voltar" class="btn btn-danger">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/tipo/tipo.blade.php ENDPATH**/ ?>