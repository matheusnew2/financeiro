<?php $__env->startSection('title'); ?>
Listagem de contas fixas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <form method="POST" action="<?php echo e(asset('ContaFixa')); ?>" class="form-group">
            <?php echo csrf_field(); ?>
            <?php if(isset($result)): ?>
                <?php if(($result->id_fixo) !== NULL): ?>
            <input type="hidden" name="id_fixo" value="<?php echo e($result->id_fixo); ?>">
                <?php endif; ?>
            <?php endif; ?>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group col-sm-12">
                        <label for="nome">Nome</label>
                        <input type="text" name="nome" id="nome" value="<?php if(isset($result->nome)): ?><?php echo e($result->nome); ?> <?php endif; ?>" required class="form-control">
                    </div>
                    <div class="form-group col-sm-5">
                        <label for="valor">Valor</label>
                        <input type="text" name="valor" id="valor" value="<?php if(isset($result->valor)): ?><?php echo e($result->valor); ?> <?php endif; ?>" class="form-control">
                    </div>
                    <div class="col-sm-12">
                        <input type="submit" class="btn btn-success">
                        <input type="button" onclick="window.location.href='<?php echo e(asset('ListaContaFixa')); ?>'" value="Voltar" class="btn btn-danger">

                    </div>
                </div>
            </div>

        </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extras'); ?>
<?php if(isset($mensagem) && $mensagem != ""): ?>
<script type="text/javascript">
    alert('<?php echo e($mensagem); ?>');
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/fixo/Cadastrarfixo.blade.php ENDPATH**/ ?>