<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
    function cobrir(from,to){
        event.preventDefault();
        $('#'+from).removeAttr("onclick");
        $('#'+from).attr("onclick",'descobrir("'+from+'","'+to+'")');
        $('#'+to).fadeOut(800);
        
        
    }
    function descobrir(from,to){
        event.preventDefault();
        $('#'+from).removeAttr("onclick");
        $('#'+from).attr("onclick",'cobrir("'+from+'","'+to+'")');
        $('#'+to).fadeIn(800);
    }
        
    
</script>
<?php $__env->stopSection(); ?>
<div class="container-fluid">
    
    <div class="row">
        <div class="col-md-12 row">
            <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-md-6 mb-4" style="padding-right: 0px">
                <div class="card shadow h-100 py-2"  style="border-left: .25rem solid <?php if($conta->saldo >= 0): ?>green <?php elseif($conta->saldo < 0): ?> red <?php endif; ?> !important;">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold  text-uppercase mb-1" style="color:black">Conta: <?php echo e($conta->id_conta." - ".$conta->nome); ?> </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"  id='conta<?php echo e($conta->id_conta); ?>'>R$ <div style="display: inline-block;;color: <?php if($conta->saldo >= 0): ?>green <?php elseif($conta->saldo < 0): ?> red <?php endif; ?>"> <?php echo e(number_format($conta->saldo,2,",",".")); ?></div></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-eye fa-2x text-gray-300" id='olho<?php echo e($conta->id_conta); ?>' onclick="cobrir(<?php echo e("'olho".$conta->id_conta."','conta".$conta->id_conta."'"); ?>)"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-md-6 mb-4" style="padding-right: 0px">
                <div class="card shadow h-100 py-2"  style="border-left: .25rem solid green !important;">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold  text-uppercase mb-1" style="color:black">Saldo mes atual</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"  id="saldo" >R$ <div style="display: inline-block;;color: green"><?php echo e(number_format($saldo,2,",",".")); ?></div></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-eye fa-2x text-gray-300" id='olhoMes' onclick="cobrir('olhoMes','saldo')"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extras'); ?>
<!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  <script src="js/demo/chart-bar-demo.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>