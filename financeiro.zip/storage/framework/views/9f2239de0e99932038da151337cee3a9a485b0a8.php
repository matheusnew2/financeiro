<?php $__env->startSection('title'); ?>
Lançamento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <form method="POST" action="<?php echo e(asset('Lancamento')); ?>" class="form-row form-group">
            <?php echo csrf_field(); ?>
            <?php if(isset($result->id_lancamento)): ?>
            <input type="hidden" value="<?php echo e($result->id_lancamento); ?>" name="id_lancamento">
            <?php endif; ?>
            <div class="col-sm-6">
                <div class="form-group col-sm-12">
                    <label for="tipo">Tipo</label>
                    <select class="form-control" name="id_tipo" required>
                        <option value="">Selecione</option>
                        <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo->id_tipo); ?>" <?php if(isset($result->tipo_id_tipo)): ?> <?php if($tipo->id_tipo == $result->tipo_id_tipo): ?><?php echo e('selected'); ?><?php endif; ?> <?php endif; ?> ><?php echo e($tipo->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-sm-12">
                    <label for="valor">Valor</label>
                    <input type="text" name="valor" value="<?php if(isset($result->valor)): ?><?php echo e($result->valor); ?><?php endif; ?>" required class="form-control">
                </div>
                <div class="form-group col-sm-12">
                    <label for="descricao">Descrição</label>
                    <textarea name="descricao" required  class="form-control"><?php if(isset($result->descricao)): ?><?php echo e($result->descricao); ?><?php endif; ?></textarea>
                </div>
                <div class="form-group col-sm-12">
                    <label for="descricao">Periodo</label>
                    <input type="date" name="periodo" value="<?php if(isset($result->periodo)): ?><?php echo e($result->periodo); ?><?php endif; ?>" required class="form-control">
                </div>
                <div class="form-group col-sm-12">
                    <label for="descricao">Investimento</label>
                    <div class="row">
                        <div class=" col-sm-2">
                            <label class="form-check-label" style="padding-top:10px">
                                <input type="radio" class="form-check-inline" required name="investimento" <?php if(isset($result->investimento)): ?> <?php if($result->investimento == 'S'): ?><?php echo e('checked'); ?><?php endif; ?> <?php endif; ?> value="S">Sim
                            </label>
                        </div>
                         <div class=" col-sm-2">
                             <label class="form-check-label" style="padding-top:10px">
                                <input type="radio" class="form-check-inline" name="investimento" <?php if(isset($result->investimento)): ?> <?php if($result->investimento == 'N'): ?><?php echo e('checked'); ?><?php endif; ?> <?php endif; ?> value="N">Não
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-12">
                    <input type="submit" class="btn btn-success">
                    <input type="button" onclick="window.location.href='<?php echo e(asset('ListaLancamento')); ?>'" value="Voltar" class="btn btn-danger">
                </div>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/lancamento/lancamento.blade.php ENDPATH**/ ?>