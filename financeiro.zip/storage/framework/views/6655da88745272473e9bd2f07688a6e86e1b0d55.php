<?php $__env->startSection('title'); ?>
Tipo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <form method="POST" action="<?php echo e(asset('Conta')); ?>" id="form" class="form-row form-group">
        <?php if(isset($tela->id_conta)): ?>
        <input type="hidden" value="<?php echo e($tela->id_conta); ?>" name="id_movimentacao">
        <?php endif; ?>
        
        <div class="col-sm-6">
           
            <div class="form-group col-sm-12">
                <label for="valor">Nome</label>
                <input type="text" name="nome" value="<?php if(isset($tela->nome)): ?><?php echo e($tela->nome); ?><?php endif; ?>" required class="form-control">
            </div>
            <div class="form-group col-sm-12">
                <label for="descricao">Tipo</label>
                <select class="form-control" name="tipo">
                    <option value="P" <?php if(isset($tela->tipo)): ?> <?php if($tela->tipo == 'P'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?> >Principal</option>
                    <option value="F" <?php if(isset($tela->tipo)): ?> <?php if($tela->tipo == 'F'): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>>Fundo</option>
                </select>
            </div>
            

            <div class="col-sm-12">
                <input type="submit" class="btn btn-success">
                <?php if(isset($tela->id_conta) && $tela->id_conta != ''): ?>
                <input type="button" onclick="window.location.href='<?php echo e(asset('ListaMovimentacao')); ?>'" value="Cancelar" class="btn btn-danger">
                <?php endif; ?>
                <input type="button" onclick="window.location.href='<?php echo e(asset('ListaConta')); ?>'" value="Voltar" class="btn btn-warning">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extras'); ?>
<?php if(isset($mensagem) && $mensagem != ""): ?>
<script type="text/javascript">
    alert('<?php echo e($mensagem); ?>');
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/conta/conta.blade.php ENDPATH**/ ?>