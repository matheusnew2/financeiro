<?php $__env->startSection('title'); ?>
Lista de tipos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-bordered">
                <tr>
                    <th>Nome</th>
                    <th>Saldo</th>
                </tr>
                <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="Conta/<?php echo e($conta->id_conta); ?>" ><?php echo e($conta->nome); ?></a></td>
                    <td>
                        <?php echo e($conta->saldo); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <?php echo $contas->links(); ?>

        </div>
        <div class="col-sm-12">
            <input type="button" class="btn btn-success" onclick="window.location.href = '<?php echo e(asset('Conta')); ?>'" value="Novo">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/conta/listaConta.blade.php ENDPATH**/ ?>