<?php $__env->startSection('title'); ?>
Lista de lançamentos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <table class="table tab ">
                <tr >
                    <th class="table-responsive-md">Titulo</th>
                    <th >Tipo</th>
                    <th>Valor</th>
                    <th>Situaçao</th>
                    <th>Observaçao</th>
                </tr>
                <?php $__currentLoopData = $movimentacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimentacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td <?php if(isset($movimentacao->situacao) && $movimentacao->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?>><?php echo e($movimentacao->titulo); ?></td>
                    <td width="15%" <?php if(isset($movimentacao->situacao) && $movimentacao->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?>><a href="Movimentacao/<?php echo e($movimentacao->id_movimentacao); ?>" >
                                        <?php if($movimentacao->tipo == 'L'): ?>
                                            <?php echo e('Lucro'); ?>

                                        <?php elseif($movimentacao->tipo == 'D'): ?>
                                            <?php echo e('Despesa'); ?>

                                        <?php endif; ?>
                                    </a>
                    </td>
                    <td width="15%" <?php if(isset($movimentacao->situacao) && $movimentacao->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?>><?php echo e($movimentacao->valor); ?></td>
                    <td width="15%" >
                        <?php if($movimentacao->situacao == 'A'): ?>
                            Ativo
                        <?php elseif($movimentacao->situacao == 'I'): ?> 
                            Inativo
                        <?php endif; ?>
                    </td>
                    <td <?php if(isset($movimentacao->situacao) && $movimentacao->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?>><?php echo e($movimentacao->observacao); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <?php echo $movimentacoes->links(); ?>

        </div>
        <div class="col-sm-12">
            <input type="button" class="btn btn-success" onclick="window.location.href = '<?php echo e(asset('Movimentacao')); ?>'" value="Novo">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/movimentacao/listaMovimentacao.blade.php ENDPATH**/ ?>