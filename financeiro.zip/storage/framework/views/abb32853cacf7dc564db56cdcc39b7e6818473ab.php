<?php $__env->startSection('title'); ?>
Lista de lançamentos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-bordered">
                <tr>
                    <th>Nome</th>
                    <th>Valor</th>
                    <th>Tipo</th>
                </tr>
                <?php $__currentLoopData = $lancamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lancamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="Lancamento/<?php echo e($lancamento->id_lancamento); ?>" ><?php echo e($lancamento->descricao); ?></a></td>
                    <td><?php echo e($lancamento->valor); ?></td>
                    <td><?php echo e($lancamento->tipo_id_tipo); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <?php echo $lancamentos->links(); ?>

        </div>
        <div class="col-sm-12">
            <input type="button" class="btn btn-success" onclick="window.location.href = '<?php echo e(asset('Lancamento')); ?>'" value="Novo">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/lancamento/listaLancamento.blade.php ENDPATH**/ ?>