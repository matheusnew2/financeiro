<?php $__env->startSection('title'); ?>
Lançamento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if((isset($tela->situacao) && $tela->situacao != 'I') || !isset($tela->situacao)): ?>
    <form method="POST" action="<?php echo e(asset('Movimentacao')); ?>" id="form" class="form-row form-group">
    <?php endif; ?>
        <?php if(isset($tela->id_movimentacao)): ?>
        <input type="hidden" value="<?php echo e($tela->id_movimentacao); ?>" name="id_movimentacao">
        <?php endif; ?>
        <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?>
        <div class="col-sm-6">
            <div class="form-group col-sm-12">
                <input type="text" class="form-control" style="background-color: red;color:white" disabled value="Movimentacao cancelada">
            </div>
        </div>
        <?php endif; ?>
        <div class="col-sm-6">
            <div class="form-group col-sm-12">
                <label for="titulo">Titulo*</label>
                <input type="text" class="form-control" name="titulo" <?php if(isset($tela->titulo) && $tela->titulo == 'I'): ?> disabled <?php endif; ?> value="<?php if(isset($tela->data_movimentacao)): ?><?php echo e($tela->titulo); ?><?php endif; ?>">
            </div>
            <div class="form-group col-sm-12">
                <label for="tipo">Tipo*</label>
                <select class="form-control" <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?> name="tipo" required>
                    <option value="">Selecione</option>
                    <option value="L" <?php if($tela->tipo == "L"): ?> selected <?php endif; ?> >Lucro</option>
                    <option value="D" <?php if($tela->tipo == "D"): ?> selected <?php endif; ?> >Despesa</option>
                </select>
            </div>
            <div class="form-group col-sm-12">
                <label for="conta_id_conta">Conta*</label>
                <select class="form-control" <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?> name="conta_id_conta" required>
                    <option value="">Selecione</option>
                    <?php $__currentLoopData = $contas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <option value="<?php echo e($conta->id_conta); ?>" 
                        <?php if($conta->id_conta == $tela->conta_id_conta): ?>
                            selected
                        <?php endif; ?> 
                    ><?php echo e($conta->id_conta.' - '.$conta->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="form-group col-sm-12">
                <label for="valor">Valor*</label>
                <input type="text" name="valor" <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?>style='text-decoration: line-through;'<?php endif; ?> value="<?php if(isset($tela->valor)): ?><?php echo e($tela->valor); ?><?php endif; ?>" required class="form-control">
            </div>
            <div class="form-group col-sm-12">
                <label for="data_movimentacao">Data movimentacao*</label>
                <input type="date" name="data_movimentacao" <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?> disabled <?php endif; ?> value="<?php if(isset($tela->data_movimentacao)): ?><?php echo e($tela->data_movimentacao); ?><?php endif; ?>" 
                required class="form-control">
            </div>

            <div class="form-group col-sm-12">
                <label for="observacao">Observacao*</label>
                <textarea name="observacao" required <?php if(isset($tela->situacao) && $tela->situacao == 'I'): ?> style='text-decoration: line-through;'}<?php endif; ?> class="form-control"><?php if(isset($tela->observacao)): ?><?php echo e($tela->observacao); ?><?php endif; ?> </textarea>
            </div>


            <div class="col-sm-12">
                <?php if((isset($tela->situacao) && $tela->situacao != 'I') || !isset($tela->situacao)): ?>
                <input type="submit" class="btn btn-success">
                <?php endif; ?>
                <?php if(isset($tela->id_movimentacao) && $tela->id_movimentacao != '' && (isset($tela->situacao) && ($tela->situacao != 'I' || $tela->situacao == 'A'))): ?>
                <a onclick="cancelar(<?php echo e($tela->id_movimentacao); ?>,'<?php echo e(asset('Movimentacao/Cancelar/'.$tela->id_movimentacao)); ?>','<?php echo e(asset('Movimentacao')); ?>')"><input type="button" name="cancelar"  value="Cancelar" class="btn btn-danger"></a>
                <?php endif; ?>
                <input type="button" onclick="window.location.href='<?php echo e(asset('ListaMovimentacao')); ?>'" value="Voltar" class="btn btn-warning">
                
            </div>
        </div>
    <?php if((isset($tela->situacao) && $tela->situacao != 'I') || !isset($tela->situacao)): ?>
    </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extras'); ?>

<?php if(isset($mensagem) && $mensagem != ""): ?>
<script type="text/javascript">
    alert('<?php echo e($mensagem); ?>');
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\financeiro\resources\views/movimentacao/movimentacao.blade.php ENDPATH**/ ?>